/**
 * Snypar Resdex Form Auto-Filler Content Script
 * Runs inside the authenticated Naukri Resdex tab opened by Naukri Launcher.
 *
 * Strategy:
 *  - Each keyword is typed character-by-character, then confirmed with Enter / suggestion click
 *  - Before clicking "Search Candidates", verifies DOM state: chips exist for keywords,
 *    experience fields have values, etc. — NOT time-based.
 */

const BACKEND_URLS = [
  "https://recruitment-document-tools.onrender.com/search/active-plan",
  "http://127.0.0.1:8001/search/active-plan",
  "http://localhost:8001/search/active-plan",
];
let lastProcessedTimestamp = 0;
let isFilling = false;
let isPaused = false;          // True while user has paused mid-fill
let lastFillCompletedAt = 0;
const FILL_COOLDOWN_MS = 90_000; // 90s minimum between auto-triggered fills
const FILL_CACHE_KEY = "snypar_last_fill_ts"; // sessionStorage key

// Naukri Resdex URL patterns  (ground truth from selectors.py)
// Form page:    https://resdex.naukri.com/v3?activeTab=advSrch
// Results page: https://resdex.naukri.com/v3/search?sid=...
const RESDEX_FORM_URL = "https://resdex.naukri.com/v3?activeTab=advSrch";

function isOnResultsPage() {
  const href = window.location.href;
  // Results page always has /v3/search in the path (the form page is /v3 without /search)
  return href.includes("/v3/search");
}

function isOnFormPage() {
  return !isOnResultsPage();
}

// ─── Floating Status Widget ──────────────────────────────────────────────────

function createFloatingWidget() {
  if (document.getElementById("snypar-resdex-floating-badge")) return;
  const badge = document.createElement("div");
  badge.id = "snypar-resdex-floating-badge";
  badge.innerHTML = `
    <span class="snypar-badge-dot" id="snypar-dot"></span>
    <span id="snypar-status-text" style="font-weight:500;">⚡ Snypar Bot Active</span>
    <button class="snypar-badge-btn pause" id="snypar-pause-btn" style="display:none;" title="Pause auto-fill">⏸ Pause</button>
    <button class="snypar-badge-btn resume" id="snypar-resume-btn" style="display:none;" title="Resume auto-fill">▶ Resume</button>
  `;
  document.body.appendChild(badge);

  document.getElementById("snypar-pause-btn").addEventListener("click", () => {
    isPaused = true;
    updateWidgetStatus("⏸ Paused — click Resume to continue", "busy");
    showToast("⏸ Auto-fill paused. Click Resume to continue.");
  });

  document.getElementById("snypar-resume-btn").addEventListener("click", () => {
    isPaused = false;
    updateWidgetStatus("▶ Resuming...", "busy");
    showToast("▶ Auto-fill resumed.");
  });
}

/**
 * updateWidgetStatus — updates dot state + text + shows/hides Pause/Resume buttons.
 * state: "online" | "offline" | "busy" | "paused"
 * showPause: true  → show Pause button (bot is filling, not paused)
 * showPause: false → hide both buttons (idle/done/error)
 * showPause: "paused" → hide Pause, show Resume
 */
function updateWidgetStatus(text, state = "online", buttonMode = "none") {
  const dot = document.getElementById("snypar-dot");
  const label = document.getElementById("snypar-status-text");
  const pauseBtn = document.getElementById("snypar-pause-btn");
  const resumeBtn = document.getElementById("snypar-resume-btn");
  if (!dot || !label) return;

  label.innerText = text;
  dot.className =
    "snypar-badge-dot " +
    (state === "offline" ? "offline" : state === "busy" ? "busy" : "");

  // Pause button: show only while actively filling and not paused
  if (pauseBtn) pauseBtn.style.display  = buttonMode === "filling" ? "flex" : "none";
  // Resume button: show only while paused mid-fill
  if (resumeBtn) resumeBtn.style.display = buttonMode === "paused"  ? "flex" : "none";
}

function showToast(message) {
  const existing = document.querySelector(".snypar-toast");
  if (existing) existing.remove();
  const toast = document.createElement("div");
  toast.className = "snypar-toast";
  toast.innerText = message;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.transition = "opacity 0.5s ease";
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 500);
  }, 4000);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Pausable sleep — sleeps for `ms`, but also polls isPaused every 300ms.
 * If paused, it suspends until resumed. Call this between major steps.
 */
async function pausableSleep(ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    await sleep(Math.min(300, end - Date.now()));
  }
  // After base sleep, wait indefinitely while paused
  while (isPaused) {
    updateWidgetStatus("⏸ Paused — click Resume to continue", "busy", "paused");
    await sleep(300);
  }
}

// ─── React-Compatible Value Setter ──────────────────────────────────────────

function setNativeValue(el, value) {
  const nativeSetter = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype,
    "value"
  ).set;
  nativeSetter.call(el, value);
}

// ─── Shared suggestion selectors (autocomplete + AI suggested keywords) ────────
// Covers Naukri's regular autocomplete items AND the "✨ AI suggested keywords" chips.
const SUGGESTION_SELECTORS = [
  // Standard and React suggestor items
  "div.sug-item", "li.sug-item", "span.sug-item",
  "div.sug-text", "span.sug-text",
  "div.tuple", "div.tuple-wrap", "span.tuple-wrap",
  "li.suggestion-item", "div.suggestion-item",
  "div.keyword-sug", "li.keyword-sug",
  "ul.suggestor-list li", "div.suggestor-list div",
  "li[role='option']", "div[role='option']",
  "div[class*='dropdown'] div", "div[class*='dropdown'] li", "div[class*='dropdown'] span",
  "div[class*='suggestor'] li", "div[class*='suggestor'] div", "div[class*='suggestor'] span",
  "div[class*='sugItem']", "li[class*='sugItem']", "span[class*='sugItem']",
  "div[class*='sug-container'] *",
  "div[class*='option']", "li[class*='option']",
  "div.location-item", "li.location-item",
  "[role='listbox'] [role='option']", "[role='listbox'] li", "[role='listbox'] div",
  "div[class*='dropdown-menu'] *",
  "div[class*='menu'] li", "div[class*='menu'] div",
  // AI suggested keywords panel chips
  "div[class*='aiKeyword']", "span[class*='aiKeyword']", "button[class*='aiKeyword']",
  "div[class*='ai-keyword']", "span[class*='ai-keyword']", "button[class*='ai-keyword']",
  "div[class*='suggestedKeyword'] span", "div[class*='suggestedKeyword'] button", "div[class*='suggestedKeyword']",
  "div[class*='suggested-keyword'] span", "div[class*='suggested-keyword'] button", "div[class*='suggested-keyword']",
  "div[class*='keywordSuggest'] span", "div[class*='keywordSuggest'] button",
  "div[class*='aiSuggest'] span", "div[class*='aiSuggest'] button",
  "div[class*='recommend'] span", "div[class*='recommend'] button",
].join(", ");

// Poll until any visible suggestion appears (up to maxMs)
async function waitForDropdown(maxMs = 1500) {
  const step = 150;
  let elapsed = 0;
  while (elapsed < maxMs) {
    await sleep(step);
    elapsed += step;
    const sugs = document.querySelectorAll(SUGGESTION_SELECTORS);
    if (Array.from(sugs).some(s => s.offsetParent !== null)) return true;
  }
  return false;
}

// Click the best-matching visible suggestion for targetText.
// Scored matching: exact match (100) → normalized match (95) → prefix match (80) → word token overlap (40-70).
// Never clicks arbitrary unrelated suggestions.
function clickBestSuggestion(targetText, activeInput = null) {
  if (!targetText) return false;
  const target = targetText.toLowerCase().trim();
  const targetNorm = target.replace(/[^a-z0-9]/g, '');
  const tokens = target.split(/[\s\/\-_,]+/).filter(w => w.length >= 2);

  const all = Array.from(document.querySelectorAll(SUGGESTION_SELECTORS))
    .filter(s => s.offsetParent !== null && s.textContent.trim().length > 0);

  if (all.length === 0) return false;

  let bestScore = -1;
  let bestItem = null;

  for (const item of all) {
    const text = item.textContent.trim().toLowerCase();
    const textNorm = text.replace(/[^a-z0-9]/g, '');
    let score = 0;

    if (text === target) {
      score = 100;
    } else if (textNorm === targetNorm && targetNorm.length > 0) {
      score = 95;
    } else if (text.startsWith(target) || (targetNorm.length >= 3 && textNorm.startsWith(targetNorm))) {
      score = 80;
    } else if (text.includes(target) || (targetNorm.length >= 3 && textNorm.includes(targetNorm))) {
      score = 70;
    } else if (tokens.length > 0) {
      const matchTokens = tokens.filter(t => text.includes(t) || textNorm.includes(t));
      if (matchTokens.length > 0) {
        score = 40 + (matchTokens.length / tokens.length) * 30;
      }
    }

    if (score > bestScore) {
      bestScore = score;
      bestItem = item;
    }
  }

  // Only click if it's a solid match (score >= 40)
  if (bestItem && bestScore >= 40) {
    console.log(`[Snypar Bot] Selected suggestion: "${bestItem.textContent.trim()}" (score: ${Math.round(bestScore)}) for "${targetText}"`);
    bestItem.click();
    return true;
  }
  return false;
}

// Generic: type into any autocomplete field and select from dropdown (location, designation, role)
// If no dropdown option matches, confirms custom input via Enter and blur so it is preserved.
async function typeAndSelectFromDropdown(input, text, fieldLabel = '') {
  if (!text || !text.trim()) return false;
  const cleanText = text.trim();
  input.focus();
  await sleep(150);

  // Clear via execCommand + nativeSetter
  input.select();
  document.execCommand('selectAll');
  document.execCommand('delete');
  if (input.value) {
    setNativeValue(input, '');
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }
  await sleep(100);

  // Insert text
  const inserted = document.execCommand('insertText', false, cleanText);
  if (!inserted || input.value !== cleanText) {
    setNativeValue(input, cleanText);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Wait for dropdown
  const appeared = await waitForDropdown(1500);
  console.log(`[Snypar Bot] ${fieldLabel} dropdown ${appeared ? '✓' : '✗'} for "${cleanText}"`);

  // Click the best matching suggestion
  let selected = false;
  if (clickBestSuggestion(cleanText, input)) {
    await sleep(400);
    selected = true;
    console.log(`[Snypar Bot] ✓ "${cleanText}" selected (${fieldLabel})`);
  }

  // If no suggestion matched or was clicked, confirm custom value via Enter and blur
  if (!selected) {
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    input.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    await sleep(200);

    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.dispatchEvent(new Event('blur', { bubbles: true }));
    console.log(`[Snypar Bot] ✓ Confirmed "${cleanText}" as custom ${fieldLabel}`);
  }

  // Dismiss dropdown if still open
  input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
  await sleep(200);
  return true;
}

// Helper to locate the keyword section container for scoped chip counting
function getKeywordContainer(kwInput) {
  return kwInput.closest(
    ".keyword-container, .chip-container, .input-container, .tags-input, .suggestor-wrapper, div[class*='keyword'], div[class*='chip'], div[class*='tag']"
  ) || kwInput.parentElement?.parentElement || kwInput.parentElement || document;
}

function countKeywordChipsInContainer(container) {
  const chips = container.querySelectorAll(
    "div[class*='chip'], span[class*='chip'], div[class*='tag'], span[class*='tag'], li[class*='chip'], li[class*='tag'], div[class*='pill'], span[class*='pill']"
  );
  return chips.length;
}

function hasKeywordChip(keyword) {
  if (!keyword) return false;
  const norm = keyword.toLowerCase().replace(/[^a-z0-9]/g, '');
  if (!norm) return false;
  const candidates = document.querySelectorAll(
    "div[class*='chip'], span[class*='chip'], div[class*='tag'], span[class*='tag'], li[class*='chip'], li[class*='tag'], div[class*='pill'], span[class*='pill'], [class*='tuple']"
  );
  for (const c of candidates) {
    const textNorm = c.textContent.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (textNorm.includes(norm)) {
      return true;
    }
  }
  return false;
}

// Type keyword and confirm it through suggestions, Enter, Tab, comma, or blur.
// CRITICAL: NEVER delete or wipe unlisted keywords like "FastAPI"!
async function typeAndConfirmKeyword(kwInput, keyword) {
  if (!keyword || !keyword.trim()) return;
  const cleanKw = keyword.trim();
  kwInput.focus();
  await sleep(150);

  // Clear field
  kwInput.select();
  document.execCommand('selectAll');
  document.execCommand('delete');
  if (kwInput.value) {
    setNativeValue(kwInput, '');
    kwInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
  await sleep(100);

  // Insert text
  const inserted = document.execCommand('insertText', false, cleanKw);
  if (!inserted || kwInput.value !== cleanKw) {
    setNativeValue(kwInput, cleanKw);
    kwInput.dispatchEvent(new Event('input', { bubbles: true }));
    kwInput.dispatchEvent(new Event('change', { bubbles: true }));
  }
  await sleep(300);

  // Wait for dropdown
  await waitForDropdown(1000);

  const container = getKeywordContainer(kwInput);
  const chipsBefore = countKeywordChipsInContainer(container);
  let confirmed = false;

  // Strategy 1: Click best matching suggestion if available
  if (clickBestSuggestion(cleanKw, kwInput)) {
    await sleep(400);
    if (hasKeywordChip(cleanKw) || countKeywordChipsInContainer(container) > chipsBefore || kwInput.value === '') {
      confirmed = true;
      console.log(`[Snypar Bot] ✓ "${cleanKw}" added via suggestion click`);
    }
  }

  // Strategy 2: Press Enter to convert into chip (standard tag input)
  if (!confirmed) {
    kwInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    kwInput.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    kwInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    await sleep(350);

    if (hasKeywordChip(cleanKw) || countKeywordChipsInContainer(container) > chipsBefore || kwInput.value === '') {
      confirmed = true;
      console.log(`[Snypar Bot] ✓ "${cleanKw}" added via Enter key`);
    }
  }

  // Strategy 3: Try Tab key
  if (!confirmed) {
    kwInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', code: 'Tab', keyCode: 9, which: 9, bubbles: true, cancelable: true }));
    kwInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Tab', code: 'Tab', keyCode: 9, which: 9, bubbles: true, cancelable: true }));
    await sleep(300);

    if (hasKeywordChip(cleanKw) || countKeywordChipsInContainer(container) > chipsBefore || kwInput.value === '') {
      confirmed = true;
      console.log(`[Snypar Bot] ✓ "${cleanKw}" added via Tab key`);
    }
  }

  // Strategy 4: Try Comma
  if (!confirmed) {
    document.execCommand('insertText', false, ',');
    kwInput.dispatchEvent(new KeyboardEvent('keydown', { key: ',', code: 'Comma', keyCode: 188, which: 188, bubbles: true, cancelable: true }));
    kwInput.dispatchEvent(new KeyboardEvent('keyup', { key: ',', code: 'Comma', keyCode: 188, which: 188, bubbles: true, cancelable: true }));
    await sleep(300);

    if (hasKeywordChip(cleanKw) || countKeywordChipsInContainer(container) > chipsBefore || kwInput.value === '') {
      confirmed = true;
      console.log(`[Snypar Bot] ✓ "${cleanKw}" added via comma`);
    }
  }

  // Verification & final blur commit
  if (confirmed || hasKeywordChip(cleanKw) || kwInput.value === '') {
    // Successfully converted into chip or accepted
    console.log(`[Snypar Bot] ✓ Keyword "${cleanKw}" successfully confirmed`);
  } else {
    // If still in input field, trigger change & blur to commit
    kwInput.dispatchEvent(new Event('change', { bubbles: true }));
    kwInput.dispatchEvent(new Event('blur', { bubbles: true }));
    await sleep(200);

    if (hasKeywordChip(cleanKw) || kwInput.value === '') {
      console.log(`[Snypar Bot] ✓ Keyword "${cleanKw}" confirmed via blur`);
    } else {
      // Clear input only so the NEXT keyword has a fresh input
      console.warn(`[Snypar Bot] ⚠ Keyword "${cleanKw}" could not be chipped; clearing input for next entry.`);
      kwInput.focus();
      kwInput.select();
      document.execCommand('selectAll');
      document.execCommand('delete');
    }
  }
  await sleep(150);
}

// ─── AI Suggested Keywords Selection ─────────────────────────────────────────

async function selectRelevantAISuggestedKeywords(requiredKws, preferredKws, mandatorySet) {
  const allTargets = [...(requiredKws || []), ...(preferredKws || [])].map(k => k.toLowerCase().trim());
  if (allTargets.length === 0) return;

  const aiChipSelectors = [
    "div[class*='aiKeyword']", "span[class*='aiKeyword']", "button[class*='aiKeyword']",
    "div[class*='ai-keyword']", "span[class*='ai-keyword']", "button[class*='ai-keyword']",
    "div[class*='suggestedKeyword'] span", "div[class*='suggestedKeyword'] button", "div[class*='suggestedKeyword']",
    "div[class*='suggested-keyword'] span", "div[class*='suggested-keyword'] button", "div[class*='suggested-keyword']",
    "div[class*='keywordSuggest'] span", "div[class*='keywordSuggest'] button",
    "div[class*='aiSuggest'] span", "div[class*='aiSuggest'] button",
    "div[class*='recommend'] span", "div[class*='recommend'] button",
  ];

  const chips = Array.from(document.querySelectorAll(aiChipSelectors.join(", ")))
    .filter(el => el.offsetParent !== null && el.textContent.trim().length > 0);

  for (const chip of chips) {
    const raw = chip.textContent.replace(/^[+\s]+/, "").trim().toLowerCase();
    const rawNorm = raw.replace(/[^a-z0-9]/g, "");
    if (!rawNorm) continue;

    const match = allTargets.find(t => {
      const tNorm = t.replace(/[^a-z0-9]/g, "");
      return tNorm === rawNorm || rawNorm.includes(tNorm) || tNorm.includes(rawNorm);
    });

    if (match && !hasKeywordChip(raw)) {
      console.log(`[Snypar Bot] Clicking AI Suggested Keyword: "${chip.textContent.trim()}"`);
      chip.click();
      await sleep(350);
      if (mandatorySet && mandatorySet.has(match)) {
        await clickKeywordStar(raw);
      }
    }
  }
}

// ─── Click Mandatory Star on a Keyword Chip ──────────────────────────────────

async function clickKeywordStar(skillName) {
  if (!skillName) return false;
  const clean = skillName.toLowerCase().trim();
  const cleanNorm = clean.replace(/[^a-z0-9]/g, '');
  const chips = document.querySelectorAll(
    "div[class*='chip'], span[class*='chip'], div[class*='tag'], span[class*='tag'], li[class*='chip'], li[class*='tag'], div[class*='pill'], span[class*='pill'], [class*='tuple']"
  );
  for (const chip of chips) {
    const chipNorm = chip.textContent.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (chipNorm.includes(cleanNorm)) {
      const star = chip.querySelector(
        "[class*='star'], [class*='Star'], [title*='Mandatory'], [title*='mandatory'], [title*='Must have'], svg, button"
      );
      if (star) {
        const cls = (star.className && star.className.toString()) || "";
        const pressed = star.getAttribute("aria-pressed");
        if (!cls.includes("active") && !cls.includes("selected") && !cls.includes("starred") && pressed !== "true") {
          star.click();
          await sleep(200);
          return true;
        }
      }
    }
  }
  return false;
}

// ─── Count keyword chips currently added ─────────────────────────────────────

function countKeywordChips() {
  return document.querySelectorAll(
    "div[class*='chip'], span[class*='chip'], div[class*='tag'], span[class*='tag'], li[class*='chip'], li[class*='tag'], div[class*='pill'], span[class*='pill']"
  ).length;
}

// ─── Expand Section ───────────────────────────────────────────────────────────

async function ensureSectionExpanded(sectionName) {
  const toggles = Array.from(
    document.querySelectorAll(
      "h2, h3, div[class*='accordion'], div[class*='section-header'], button, span[class*='header'], a"
    )
  ).filter((el) => el.textContent.toLowerCase().includes(sectionName.toLowerCase()));

  for (const t of toggles) {
    const isExpanded =
      t.getAttribute("aria-expanded") === "true" ||
      t.classList.contains("expanded") ||
      t.classList.contains("open");
    if (!isExpanded && t.offsetParent !== null) {
      t.click();
      await sleep(500);
      break;
    }
  }
}

// ─── Verify a field has a value (DOM-state check) ────────────────────────────

function fieldHasValue(selector) {
  const el = document.querySelector(selector);
  if (!el) return false;
  if (el.tagName.toLowerCase() === "select") return el.selectedIndex > 0;
  return el.value && el.value.trim().length > 0;
}

// ─── Set Experience ───────────────────────────────────────────────────────────

async function setExperience(selector, value) {
  if (value === null || value === undefined) return false;
  const valStr = String(value);
  const el = document.querySelector(selector);
  if (!el) return false;

  if (el.tagName && el.tagName.toLowerCase() === "select") {
    for (let i = 0; i < el.options.length; i++) {
      if (el.options[i].value === valStr || el.options[i].text.trim() === valStr) {
        el.selectedIndex = i;
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }
    }
    // Try closest numeric match
    for (let i = 0; i < el.options.length; i++) {
      if (parseFloat(el.options[i].text) === parseFloat(valStr)) {
        el.selectedIndex = i;
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }
    }
    return false;
  } else {
    el.focus();
    setNativeValue(el, valStr);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    await sleep(300);

    // Try clicking matching option in dropdown
    const options = document.querySelectorAll(
      "div.sug-item, li.suggestion-item, div[class*='option'], li[class*='option'], ul li"
    );
    for (const opt of options) {
      if (
        opt.textContent.trim() === valStr &&
        opt.offsetParent !== null
      ) {
        opt.click();
        await sleep(200);
        return true;
      }
    }

    // Press Enter to confirm
    el.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Enter", keyCode: 13, bubbles: true })
    );
    await sleep(200);
    return fieldHasValue(selector);
  }
}

// ─── Set Active In Dropdown ───────────────────────────────────────────────────

async function setActiveIn(value) {
  const selects = document.querySelectorAll(
    "select#activeIn, select[name='activeIn'], select#searchActivePeriod"
  );
  for (const sel of selects) {
    for (let i = 0; i < sel.options.length; i++) {
      if (sel.options[i].text.toLowerCase().includes(value.toLowerCase())) {
        sel.selectedIndex = i;
        sel.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }
    }
  }
  return false;
}

// ─── Tick Show-Only Checkboxes ────────────────────────────────────────────────

async function tickShowOnlyCheckboxes(plan) {
  const targets = [];
  if (plan?.verified_mobile) {
    targets.push({ key: "verified mobile", selector: "input#verifiedMobile, input[name='verifiedMobile']" });
  }
  if (plan?.verified_email) {
    targets.push({ key: "verified email", selector: "input#verifiedEmail, input[name='verifiedEmail']" });
  }
  if (plan?.attached_resume) {
    targets.push({ key: "attached resume", selector: "input#attachedResume, input[name='attachedResume']" });
  }

  if (targets.length === 0) return 0;

  let ticked = 0;
  for (const target of targets) {
    let input = document.querySelector(target.selector);
    if (input) {
      if (!input.checked) input.click();
      ticked++;
    } else {
      const lbl = labels.find((l) =>
        l.textContent.toLowerCase().includes(target.key)
      );
      if (lbl) {
        const cb = lbl.querySelector("input[type='checkbox']");
        if (cb) {
          if (!cb.checked) cb.click();
        } else {
          lbl.click();
        }
        ticked++;
        await sleep(100);
      }
    }
  }
  return ticked;
}

// ─── DOM-State Verification Before Search ────────────────────────────────────

async function waitForFieldsVerified(plan, timeoutMs = 12000) {
  const start = Date.now();
  const requiredKws = (plan.keywords && plan.keywords.required) || [];
  const preferredKws = (plan.keywords && plan.keywords.preferred) || [];
  const totalKws = [...new Set([...requiredKws, ...preferredKws])].length;

  while (Date.now() - start < timeoutMs) {
    const checks = [];

    // 1. Keywords chips (selectors.py: KEYWORD_CHIP)
    if (totalKws > 0) {
      const allKws = [...new Set([...requiredKws, ...preferredKws])];
      const matched = allKws.filter(kw => hasKeywordChip(kw)).length;
      checks.push({
        name: "keywords",
        ok: matched > 0 || countKeywordChips() > 0,
      });
    }

    // 2. Experience (selectors.py: MIN_EXP_INPUT uses input[name='minExp'])
    if (plan.min_experience !== null && plan.min_experience !== undefined) {
      checks.push({
        name: "min_experience",
        ok: fieldHasValue("input[name='minExp'], input#minExp, select#minExp, select[name='minExp']"),
      });
    }
    if (plan.max_experience !== null && plan.max_experience !== undefined) {
      checks.push({
        name: "max_experience",
        ok: fieldHasValue("input[name='maxExp'], input#maxExp, select#maxExp, select[name='maxExp']"),
      });
    }

    const failed = checks.filter((c) => !c.ok).map((c) => c.name);
    if (failed.length === 0) {
      console.log("[Snypar Bot] ✓ All field checks passed.");
      return true;
    }

    console.log(`[Snypar Bot] Waiting for: ${failed.join(", ")} (${Math.round((Date.now()-start)/1000)}s)`);
    updateWidgetStatus(`Verifying: ${failed.join(", ")}...`, "busy");
    await sleep(600);
  }

  console.warn("[Snypar Bot] Verification timeout — proceeding anyway.");
  return false;
}

// ─── Main Form Fill ───────────────────────────────────────────────────────────

async function fillResdexForm(plan) {
  if (isFilling) return;
  isFilling = true;
  console.log("[Snypar Bot] Starting auto-fill with SearchPlan:", plan);

  // Temporary submit intercepter to guarantee form is not submitted prematurely
  const blockSubmit = (e) => {
    e.preventDefault();
    e.stopImmediatePropagation();
    console.log("[Snypar Bot] Intercepted and blocked premature form submit");
  };
  window.addEventListener("submit", blockSubmit, true);

  try {
    // ── STEP 1: Keywords ────────────────────────────────────────────────────
    const requiredKws  = (plan.keywords && plan.keywords.required)  || [];
    const preferredKws = (plan.keywords && plan.keywords.preferred) || [];
    const allKws = [...new Set([...requiredKws, ...preferredKws])];
    const mandatorySet = new Set(requiredKws.map((k) => k.toLowerCase().trim()));

    if (allKws.length > 0) {
      updateWidgetStatus(`Keywords (0/${allKws.length})...`, "busy", "filling");

      // Ground-truth selector from selectors.py: KEYWORD_INPUT
      const kwInput = document.querySelector(
        "input[name='ezKeywordsAny'], input[placeholder*='Enter keywords like skills'], " +
        "input#keywords, input.keyword-input, input[name='keyword'], input[id*='keyword']"
      );

      if (kwInput) {
        kwInput.scrollIntoView({ behavior: "smooth", block: "center" });
        await sleep(400);

        for (let i = 0; i < allKws.length; i++) {
          const kw = allKws[i];
          updateWidgetStatus(`Keyword ${i + 1}/${allKws.length}: "${kw}"`, "busy", "filling");
          await typeAndConfirmKeyword(kwInput, kw);

          if (mandatorySet.has(kw.toLowerCase().trim())) {
            await sleep(200);
            await clickKeywordStar(kw);
          }

          // Check pause after each keyword
          await pausableSleep(200);
        }

        // Select any matching AI Suggested Keywords on the page
        updateWidgetStatus("Checking AI Suggested Keywords...", "busy", "filling");
        await selectRelevantAISuggestedKeywords(requiredKws, preferredKws, mandatorySet);
        await sleep(200);

        // Tick global mandatory checkbox if present (selectors.py: MANDATORY_KEYWORDS_CHECKBOX)
        const mustHaveCheck = document.querySelector(
          "input#must-have-checkbox, input[name='must-have-checkbox'], " +
          "input#mandatoryKeywords, input[id*='mustHave'], input[id*='mandatory']"
        );
        if (mustHaveCheck && !mustHaveCheck.checked) {
          mustHaveCheck.click();
          await sleep(200);
        }
      } else {
        console.warn("[Snypar Bot] Keyword input not found. Available inputs:",
          Array.from(document.querySelectorAll("input")).map(i => `${i.name || i.id || i.type} placeholder=${i.placeholder}`).join(", ")
        );
      }
    }

    await pausableSleep(500);

    // ── STEP 2: Experience ──────────────────────────────────────────────────
    // selectors.py: MIN_EXP_INPUT = "input[name='minExp']...", MAX_EXP_INPUT = "input[name='maxExp']..."
    if (plan.min_experience !== null && plan.min_experience !== undefined) {
      updateWidgetStatus("Experience (Min)...", "busy", "filling");
      await setExperience(
        "input[name='minExp'], input[placeholder*='Min experience'], input#minExp, select#minExp, select[name='minExp']",
        plan.min_experience
      );
      await sleep(300);
    }
    if (plan.max_experience !== null && plan.max_experience !== undefined) {
      updateWidgetStatus("Experience (Max)...", "busy", "filling");
      await setExperience(
        "input[name='maxExp'], input[placeholder*='Max experience'], input#maxExp, select#maxExp, select[name='maxExp']",
        plan.max_experience
      );
      await sleep(300);
    }

    await pausableSleep(400);

    // ── STEP 3: Location ────────────────────────────────────────────────────
    if (plan.current_location && plan.current_location.length > 0) {
      const locInput = document.querySelector(
        "input[name='locations'], input[placeholder*='Add location'], input#location"
      );
      if (locInput) {
        for (let i = 0; i < plan.current_location.length; i++) {
          const loc = plan.current_location[i];
          updateWidgetStatus(`Location ${i + 1}/${plan.current_location.length}: "${loc}"`, "busy", "filling");
          await typeAndSelectFromDropdown(locInput, loc, 'Location');
          await pausableSleep(100);
        }
      }
    }



    if (plan.include_relocation) {
      const reloCb = document.querySelector(
        "input#prefLocCheckbox, input[name='prefLocCheckbox'], input#includeRelocation"
      );
      if (reloCb && !reloCb.checked) reloCb.click();
    }

    await pausableSleep(400);

    // ── STEP 4: Salary ──────────────────────────────────────────────────────
    if (plan.salary) {
      if (plan.salary.min !== null && plan.salary.min !== undefined) {
        updateWidgetStatus("Salary (Min)...", "busy");
        const minSalInput = document.querySelector(
          "input[name='minCtc'], input#minSalary, input[placeholder*='Min salary']"
        );
        if (minSalInput) {
          minSalInput.focus();
          setNativeValue(minSalInput, String(plan.salary.min));
          minSalInput.dispatchEvent(new Event("input", { bubbles: true }));
          minSalInput.dispatchEvent(new Event("change", { bubbles: true }));
          await sleep(300);
        }
      }
      if (plan.salary.max !== null && plan.salary.max !== undefined) {
        updateWidgetStatus("Salary (Max)...", "busy");
        const maxSalInput = document.querySelector(
          "input[name='maxCtc'], input#maxSalary, input[placeholder*='Max salary']"
        );
        if (maxSalInput) {
          maxSalInput.focus();
          setNativeValue(maxSalInput, String(plan.salary.max));
          maxSalInput.dispatchEvent(new Event("input", { bubbles: true }));
          maxSalInput.dispatchEvent(new Event("change", { bubbles: true }));
          await sleep(300);
        }
      }
    }

    await sleep(400);

    // ── STEP 5: Employment Details — Designation ────────────────────────────
    if (plan.designation && plan.designation.length > 0) {
      updateWidgetStatus("Expanding Employment Details...", "busy", "filling");
      await ensureSectionExpanded("Employment Details");
      await sleep(500);

      const desigInput = document.querySelector(
        "input[name='designation'], input#designation, input[placeholder*='Designation'], input[placeholder*='designation']"
      );
      if (desigInput) {
        for (let i = 0; i < plan.designation.length; i++) {
          const desig = plan.designation[i];
          updateWidgetStatus(`Designation ${i + 1}/${plan.designation.length}: "${desig}"`, "busy", "filling");
          await typeAndSelectFromDropdown(desigInput, desig, 'Designation');
          await pausableSleep(100);
        }
      }
    }

    // ── STEP 6: Department Role ─────────────────────────────────────────────
    if (plan.department_role && plan.department_role.length > 0) {
      updateWidgetStatus("Expanding Employment Details...", "busy", "filling");
      await ensureSectionExpanded("Employment Details");
      await sleep(400);

      const roleInput = document.querySelector(
        "input[name='departmentRole'], input#departmentRole, input[placeholder*='Department'], input[placeholder*='Role']"
      );
      if (roleInput) {
        for (let i = 0; i < plan.department_role.length; i++) {
          const role = plan.department_role[i];
          updateWidgetStatus(`Dept/Role ${i + 1}/${plan.department_role.length}: "${role}"`, "busy", "filling");
          await typeAndSelectFromDropdown(roleInput, role, 'Dept/Role');
          await pausableSleep(100);
        }
      }
    }

    await pausableSleep(400);

    // ── STEP 7: Notice Period ───────────────────────────────────────────────
    if (plan.notice_period && plan.notice_period.length > 0) {
      updateWidgetStatus("Notice Period...", "busy", "filling");
      await ensureSectionExpanded("Notice Period");
      await sleep(500);

      const labels = Array.from(document.querySelectorAll("label, span, div.checkbox, li"));
      for (const np of plan.notice_period) {
        const npClean = np.toLowerCase();
        const match = labels.find((l) =>
          l.textContent.toLowerCase().includes(npClean)
        );
        if (match) {
          const cb = match.querySelector("input[type='checkbox']");
          if (cb) {
            if (!cb.checked) cb.click();
          } else {
            match.click();
          }
          await sleep(200);
        }
      }
    }

    await pausableSleep(400);

    // ── STEP 8: Additional Details (only if explicitly requested) ──────────
    if (plan.verified_mobile || plan.verified_email || plan.attached_resume) {
      updateWidgetStatus("Additional Details...", "busy", "filling");
      await ensureSectionExpanded("Additional Details");
      await sleep(500);
      const ticked = await tickShowOnlyCheckboxes(plan);
      console.log(`[Snypar Bot] Ticked ${ticked} show-only checkboxes`);
      await sleep(300);
    }

    // ── STEP 9: Active In (only if explicitly requested) ───────────────────
    if (plan.active_in) {
      updateWidgetStatus("Active In...", "busy", "filling");
      await setActiveIn(plan.active_in);
      await sleep(300);
    }

    // ── STEP 10: DOM-STATE VERIFICATION (not time-based) ───────────────────
    updateWidgetStatus("⚙ Verifying all fields...", "busy", "filling");
    showToast("⚡ Verifying all fields are complete before searching...");
    const verified = await waitForFieldsVerified(plan, 12000);

    if (!verified) {
      showToast("⚠ Some fields may not have registered — check the form.");
    }

    // ── Wait if user paused right before search ───────────────────────────────
    if (isPaused) {
      updateWidgetStatus("⏸ Paused before search — resume to submit", "busy", "paused");
      while (isPaused) { await sleep(300); }
    }

    // ── STEP 11: Click Search Candidates ────────────────────────────────────
    updateWidgetStatus("Clicking Search Candidates...", "busy");
    // Remove premature submit blocker before final submission
    window.removeEventListener("submit", blockSubmit, true);
    await sleep(600);

    let searchClicked = false;

    // Strategy A: Precise Naukri class-based selectors (never match text inputs)
    const preciseSelectors = [
      "button#searchButton",
      "button[data-testid='search-btn']",
      "button[data-testid='searchButton']",
      "a.searchProfiles",
      "button.searchProfiles",
      "button.search-btn",
      "button[class*='searchBtn']",
      "button[class*='search-btn']",
      "button[class*='SearchBtn']",
      "button[class*='srchBtn']",
      "a[class*='searchProfiles']",
    ];
    for (const sel of preciseSelectors) {
      const btn = document.querySelector(sel);
      if (btn && btn.offsetParent !== null) {
        btn.scrollIntoView({ behavior: "smooth", block: "center" });
        await sleep(400);
        btn.click();
        searchClicked = true;
        console.log(`[Snypar Bot] ✓ Search clicked via precise selector: ${sel}`);
        break;
      }
    }

    // Strategy B: Text-content match — ONLY real <button> elements, not inputs
    if (!searchClicked) {
      const allBtns = Array.from(document.querySelectorAll("button, a[role='button']"));
      const searchBtn = allBtns.find((b) => {
        const txt = b.textContent.trim().toLowerCase();
        return (txt === "search candidates" || txt === "search" && b.type === "submit") &&
               b.offsetParent !== null;
      });
      if (searchBtn) {
        searchBtn.scrollIntoView({ behavior: "smooth", block: "center" });
        await sleep(400);
        searchBtn.click();
        searchClicked = true;
        console.log(`[Snypar Bot] ✓ Search clicked via text match: "${searchBtn.textContent.trim()}"`);
      }
    }

    if (searchClicked) {
      updateWidgetStatus("✓ Search Submitted!", "online", "none");
      showToast("✓ 'Search Candidates' executed successfully on Naukri Resdex!");
    } else {
      updateWidgetStatus("✓ All Fields Filled!", "online", "none");
      showToast("✓ All criteria completed — manually click 'Search Candidates' if needed.");
      console.warn("[Snypar Bot] Search button not found. Buttons on page:",
        Array.from(document.querySelectorAll("button")).map(b => `[${b.className}] "${b.textContent.trim().substring(0,40)}"`).join(", ")
      );
    }
  } catch (err) {
    console.error("[Snypar Bot] Auto-fill error:", err);
    updateWidgetStatus("⚠ Error During Fill", "offline", "none");
    showToast(`⚠ Error: ${err.message}`);
  } finally {
    window.removeEventListener("submit", blockSubmit, true);
    isPaused = false;         // Always clear pause on completion/error
    isFilling = false;
    lastFillCompletedAt = Date.now();
  }
}

// ─── Real-Time Sync Loop (Fully Automatic, No Manual Button) ─────────────────

// Wait for keyword input field to appear (form DOM ready)
async function waitForFormReady(timeoutMs = 20000) {
  const start = Date.now();
  // Ground-truth selectors from selectors.py
  const formInputSelectors = [
    "input[name='ezKeywordsAny']",
    "input[placeholder*='Enter keywords like skills']",
    "input[placeholder*='keyword']",
    "input[placeholder*='Enter skills']",
    "input#keywords",
    "input.keyword-input",
    "input[name='keyword']",
    "input[id*='keyword']",
  ];
  while (Date.now() - start < timeoutMs) {
    for (const sel of formInputSelectors) {
      const el = document.querySelector(sel);
      if (el && el.offsetParent !== null) {
        console.log(`[Snypar Bot] ✓ Form ready — keyword input found: ${sel}`);
        return true;
      }
    }
    // Also check if we accidentally ended up on results page
    if (isOnResultsPage()) {
      console.log("[Snypar Bot] Still on results page after navigation — retrying...");
      await ensureOnFormPage();
      return false;
    }
    updateWidgetStatus(`Waiting for form... (${Math.round((Date.now()-start)/1000)}s)`, "busy");
    await sleep(700);
  }
  console.warn("[Snypar Bot] Form not detected within timeout.");
  return false;
}

// Navigate to search form page if we're on the results page
async function ensureOnFormPage() {
  if (isOnResultsPage()) {
    updateWidgetStatus("Navigating to Search Form...", "busy");
    showToast("⚡ Snypar Bot: Going to search form to fill criteria...");
    console.log("[Snypar Bot] On results page — navigating to form:", RESDEX_FORM_URL);

    // First try clicking the 'Modify' link on the results page
    const modifyLinks = Array.from(
      document.querySelectorAll("a, button, span")
    ).filter(
      (el) =>
        el.textContent.trim().toLowerCase() === "modify" ||
        el.getAttribute("href")?.includes("advanced-search")
    );
    if (modifyLinks.length > 0 && modifyLinks[0].offsetParent !== null) {
      console.log("[Snypar Bot] Clicking Modify link...");
      modifyLinks[0].click();
    } else {
      // Navigate directly to form page
      window.location.href = RESDEX_FORM_URL;
    }
    // Navigation will reload the page — the content script reinitialises on new page
    return false; // Signal: do not proceed with fill on this page
  }
  return true; // Already on form page
}

async function fetchAndFill(forced = false) {
  // ── Guard: if already filling, skip ────────────────────────────────────────
  if (isFilling) return;

  // ── Guard: on results page, just show stable status (don't auto-navigate) ──
  if (isOnResultsPage()) {
    updateWidgetStatus("✓ Search Results Active", "online");
    return;
  }

  let fetchedData = null;
  for (const url of BACKEND_URLS) {
    try {
      const res = await fetch(url);
      if (res.ok) {
        fetchedData = await res.json();
        break;
      }
    } catch (e) {}
  }

  if (!fetchedData) {
    updateWidgetStatus("Server Offline", "offline");
    return;
  }

  try {
    if (fetchedData.has_plan && fetchedData.plan) {
      const planTs = String(fetchedData.timestamp);

      // ── Guard: same plan already applied (sessionStorage cache) ────────────
      const cachedTs = sessionStorage.getItem(FILL_CACHE_KEY);
      if (!forced && cachedTs === planTs) {
        updateWidgetStatus("✓ Plan Already Applied", "online");
        return;
      }

      // ── Guard: cooldown — don't re-trigger within 90s of last fill ──────────
      const msSinceFill = Date.now() - lastFillCompletedAt;
      if (!forced && lastFillCompletedAt > 0 && msSinceFill < FILL_COOLDOWN_MS) {
        const secLeft = Math.ceil((FILL_COOLDOWN_MS - msSinceFill) / 1000);
        updateWidgetStatus(`⏳ Cooldown (${secLeft}s)`, "busy");
        return;
      }

      // ── Guard: only proceed on genuinely new plan (or forced) ───────────────
      if (!forced && fetchedData.timestamp <= lastProcessedTimestamp) {
        updateWidgetStatus("✓ Plan Already Applied", "online");
        return;
      }

      // We're on the form page — wait for form DOM to be ready
      updateWidgetStatus("Waiting for form...", "busy");
      const formReady = await waitForFormReady(15000);
      if (!formReady) {
        updateWidgetStatus("⚠ Form not found", "offline");
        showToast("⚠ Could not find Resdex search form. Please navigate to the Resdex search page.");
        return;
      }

      lastProcessedTimestamp = fetchedData.timestamp;
      showToast("⚡ Snypar Bot: Auto-filling candidate search criteria...");
      await fillResdexForm(fetchedData.plan);

      // ── Cache the applied plan timestamp so re-navigating doesn't re-fill ───
      sessionStorage.setItem(FILL_CACHE_KEY, planTs);

    } else {
      updateWidgetStatus("⚡ Snypar Bot Active", "online");
    }
  } catch (err) {
    console.error("[Snypar Bot] Processing error:", err);
  }
}

// Listen for messages from popup
if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === "TRIGGER_FILL") {
      fetchAndFill(true);
      sendResponse({ status: "filling" });

    } else if (req.action === "FORCE_FILL") {
      sessionStorage.removeItem(FILL_CACHE_KEY);
      lastFillCompletedAt = 0;
      lastProcessedTimestamp = 0;
      isPaused = false;
      console.log("[Snypar Bot] Force Re-fill triggered — cache cleared.");
      fetchAndFill(true);
      sendResponse({ status: "force-filling" });

    } else if (req.action === "PAUSE") {
      isPaused = true;
      updateWidgetStatus("\u23f8 Paused \u2014 click Resume to continue", "busy", "paused");
      showToast("\u23f8 Auto-fill paused.");
      sendResponse({ status: "paused" });

    } else if (req.action === "RESUME") {
      isPaused = false;
      updateWidgetStatus("\u25b6 Resuming...", "busy", "filling");
      showToast("\u25b6 Auto-fill resumed.");
      sendResponse({ status: "resumed" });

    } else if (req.action === "GET_STATUS") {
      sendResponse({ isFilling, isPaused, onResultsPage: isOnResultsPage() });
    }
    return true;
  });
}


// ─── Initialize on Page Load ──────────────────────────────────────────────────

let syncIntervalStarted = false;
function initSync() {
  if (syncIntervalStarted) return;
  syncIntervalStarted = true;
  createFloatingWidget();
  setInterval(() => fetchAndFill(false), 2000);
  fetchAndFill(false);
}

if (window.location.href.includes("resdex.naukri.com")) {
  if (document.readyState === "complete" || document.readyState === "interactive") {
    initSync();
  } else {
    window.addEventListener("DOMContentLoaded", initSync);
    window.addEventListener("load", initSync);
  }
}
